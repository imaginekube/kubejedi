import Basic from "./Basic";
import Generator from "../../utils/Generator";

const LevelLeft = Generator({ componentCls: "level-left" })(Basic);

export default LevelLeft;
