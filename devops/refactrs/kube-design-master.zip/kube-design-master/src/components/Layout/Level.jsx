import Basic from "./Basic";
import Generator from "../../utils/Generator";

const Level = Generator({ componentCls: "level" })(Basic);

export default Level;
