import Basic from "./Basic";
import Generator from "../../utils/Generator";

const Column = Generator({ componentCls: "column" })(Basic);

export default Column;
