import Basic from "./Basic";
import Generator from "../../utils/Generator";

const LevelRight = Generator({ componentCls: "level-right" })(Basic);

export default LevelRight;
