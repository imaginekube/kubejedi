import Basic from "./Basic";
import Generator from "../../utils/Generator";

const Columns = Generator({ componentCls: "columns" })(Basic);

export default Columns;
