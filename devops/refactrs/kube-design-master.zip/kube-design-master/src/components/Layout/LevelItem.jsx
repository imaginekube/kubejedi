import Basic from "./Basic";
import Generator from "../../utils/Generator";

const LevelItem = Generator({ componentCls: "level-item" })(Basic);

export default LevelItem;
