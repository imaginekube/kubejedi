import Menu from "./Menu";
import MenuItem from "./MenuItem";

Menu.MenuItem = MenuItem;

export default Menu;
