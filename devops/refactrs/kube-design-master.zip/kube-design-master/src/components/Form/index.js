import Form from "./Form";
import Item from "./Item";
import Group from "./Group";

Form.Item = Item;
Form.Group = Group;

export default Form;
