import Input from "./Input";
import InputSearch from "./InputSearch";
import InputPassword from "./InputPassword";

export { Input, InputSearch, InputPassword };
