import React from "react";

const TableContext = React.createContext({});

export default TableContext;
